# Academic Task 1 陪练教学底稿

本底稿来自《小作文讲义.pdf》26页全部正文及图页、10.15写作.docx全部40个正文段落和2张原图。页码为PDF物理页码；DOCX以文档正文顶层块B编号定位。已核对原图，正文提取不是图表事实来源。标记「材料」表示原课件教学意图；「修正」表示纠错；「补充」表示为实际陪练补全的方法。官方考试格式和评分以根目录官方核实资料为准。这里覆盖Academic Task 1，不声称完成Task 2课程。

## 1. 老师真正要求学生学会什么

材料的主线是：改写题目→先找整体特征→按有意义的类别分段→补关键细节；句子训练围绕完整的数量主语、趋势动词、数值单位与时态。10.15课堂将这条主线落实到「英/瑞总体降，意/葡升」和「本地先升后降，另两类升」。流程图改为识别阶段、顺序与原料变化；地图改为识别功能与位置的变化。学习目标应是读图决策，不能变成背「五大万能句型」。

材料p3的「改2–3处」、p11的「overview两句话不写数值」、p10–11的四段框架都是课堂脚手架，不是机械的官方条文。优先保证意义完整；不能为了同义替换丢掉per person、total duration、national and international、固定电话等限定。推荐默认四段：引言、overview、细节1、细节2；overview放末尾也可，关键是清楚存在。无需再重复一段结论或写个人意见。

## 2. 讲义式完整示范与用户练习

用户要求详细教学、按讲义逐步讲解或完整带题时，采用完整示范：展示实际题图，读出对象、指标、单位和时间，确定分段，再逐句写出引言、overview及两个细节段。每写一句，紧接解释所选信息、核心词块、句法和承接关系。最后把四段合成完整文章。解释采用直接、正向陈述。

用户明确提出自己动笔练习时，按当前目标给3–6分钟任务，收到作答后反馈并继续下一步。用户索要范文、答案、完整改稿时直接提供。下面的互动闭环适用于用户选择练习的场景。

标准闭环：
1. 读图核事实：题干、图例、轴、单位、时段、数据是实测还是预测、能否准确读数。
2. 找2–3个主要特征：方向/排序/突出变化/趋近或分化。不要每条线逐年流水账。
3. 选择分组：相同走势、相关类别、明显对照、空间区域或加工阶段；不必所有题固定上升段和下降段。
4. 用户写当前目标的句子或段落；等用户交稿。
5. 反馈先看事实和任务完成，再看组织、用词、语法。给「原句→最小改动→理由」，优先3个高价值问题。保留正确且自然的用户表达。
6. 用户重写1–3句；用同图另一组数据或另一张图做迁移。没有交稿不能编造已掌握、错误频率或完成记录。

小任务不评整篇band。完整作答可依据Task Achievement、Coherence and Cohesion、Lexical Resource、Grammatical Range and Accuracy给有证据的教学估计，说明不是正式考官分数；不能根据几个高级词推分。Task1至少150词；用户交来不足150词的完整稿仍应照常反馈各项，并指出字数及内容展开不足，不能以字数为由拒绝批改。若缺图，先要求题图或可靠题干数据，不能凭印象校正数据。

## 3. 两张10.15真实图：读图与批改依据

### CO2（10.15 B1–12，word/media/image1.png）

图：英国、瑞典、意大利、葡萄牙1967–2007年**人均平均CO2排放**；单位metric tonnes **per person**，年份1967/1977/1987/1997/2007。原图在../assets/writing-1015-image1.png。

读图近似值仅作为教师核对容差，不假称数据表精确值：

| 国家 | 1967 | 1977 | 1987 | 1997 | 2007 |
|---|---:|---:|---:|---:|---:|
| UK | 10.7–10.9 | 10.6–10.8 | 9.9–10.1 | 9.4–9.7 | 8.6–9.0 |
| Sweden | 8.4–8.7 | 10.1–10.4 | 6.9–7.2 | 5.8–6.1 | 5.3–5.6 |
| Italy | 4.0–4.3 | 6.1–6.4 | 6.6–6.9 | 7.5–7.8 | 7.5–7.8 |
| Portugal | 1.0–1.3 | 2.0–2.2 | 3.1–3.4 | 5.1–5.4 | 5.3–5.6 |

可教overview：英国一直最高；英瑞终点低于起点，意葡终点高于起点；国家间差距缩小。瑞典不是全程下降，其1977年达到峰值后下降；葡萄牙终点与瑞典接近。意大利在1987与1997之间超过瑞典，可写by 1997已超过，不能捏造精确交叉年/精确交叉数值。意大利1997–2007基本不变，英国1967–1977近乎持平，因此steadily/consistently falling须谨慎。

分组A：英瑞总体下降（各写起点、瑞典峰值、终点）；B：意葡上升（起终点、意大利后期平台、两国末期比较）。也可按初末变化分组，只要比较清楚。

课堂稿逐项修正：
- B4 `emissions ... while that of ...`：emissions为复数用those；更稳用`the figures for Italy and Portugal`。不能把排放概念替换成国家本身。
- B4 `the UK ... highest amount`：须补`per person`，不从人均图推论总排放最多。
- B6 `Despite + 完整主谓从句`不成立。可选`Although the gap ... narrowed, ...`或`Despite a considerable narrowing of the gap, ...`。虽然正确但第二种更重，按用户水平选。
- B10 `emissions ... was`改were；或用完整数量表达`average per-capita emissions in the UK stood at...`；需要单数主语时用`the figure for the UK was...`。`11 ... to 9`应加about，原图近似。
- B10 `sharp growth`可用`sharp rise`，更自然；1977峰值不能遗失。
- B12 `It climbed ... and overtaking`改`... and overtook ...`或`..., overtaking ...`，须核实交叉时点；不能写不存在的完整精确数值。
- B1/2/10/12的xxx和B16癌症改写词汇串是课堂未完草稿，不是标准范文。癌症题无配图，不补造题意或数据。

### UK telephone calls（10.15 B27–36，word/media/image2.png）

英国1995–2002年三类通话的总时长；单位billions of minutes（十亿分钟）。三类是Local–fixed line、National and international–fixed line、Mobiles (all calls)。不能省去international，不能将时长改成次数、人数或频率。原图../assets/writing-1015-image2.png。

| 类型 | 1995 | 1999 | 2002 |
|---|---:|---:|---:|
| Local fixed line | 71–73 | 89–91 | 71–73 |
| National/international fixed line | 36–38 | 49–51 | 60–62 |
| Mobiles | 2–4 | 12–14 | 44–46 |

大图事实：本地固定电话全程总时长最多，先升至1999年前后90 billion分钟再降至约原起点；另两类逐年升，手机从最低起点增长尤快；差距缩小，但不能因此说手机最终最多。1998/1999峰附近很接近，1999柱略高；用around 90 billion in 1999可接受。不要用`fluctuated`泛指一次先升后降。`used most frequently`推频率超出图证据，改`accounted for the greatest total call duration`或`recorded the highest total number of minutes`。

分组A单写本地完整弧线；B比较另两类的起终点，注意mobile相对增幅大但2002仍少于national/international。原稿`time of mobiles`不自然，用`time spent on mobile calls`/`the total duration of mobile calls`；`consistently to be used`缺谓语，采用`remained...`更简洁。`bm`、`mt`不是必须缩写，150词文内通常直接写billion minutes/tonnes清楚。

## 4. 动态、静态与混合图的决策

动态：比较变化而非罗列；选起点/终点/转折/峰值/有意义交叉。静态：只有一个时间截面，不能用increase/decrease；比较排序、差距、倍数与份额。仅两年的图可以同时比较起终点及净变化，但不能凭两点推持续稳步变化。混合图先查是否同一单位、对象、时间，若不能直接相加就分别概述联系。

数量主语：`the number of cars` + 单数谓语；`cars` + 复数谓语；`the proportion of people`是比例，不是人数；`average emissions per person`不是总量。`rose to 60`写终点，`rose by 20`写增量；30%到40%是10 percentage points或约33%相对增加，不能称增长10%。

材料同义词表的修正（p4–9）：account for表达份额时不是「归因」；occupy优先用于空间，份额优先account for/make up。budget是预算，不等于实际支出；cost是成本/价格，spending是支出；sales可以是数量或金额，turnover常指销售收入，不能不看单位就替换；salary和wage语域/计酬方式不同。`almost/nearly`低于目标数值，`about/approximately`可两侧近似；`stabilised`暗示变化后趋稳，不等于始终unchanged；rapidly是速度快，significantly是幅度大；gradually与slightly不能当完全同义。`most amount`改largest amount；`same/similar`用法区别：the same pattern / a similar pattern。

句型选择先用简单完整句：`The figure rose from A to B.`和`There was a rise in X.`足够。`X saw...`可用但不必每句拟人；`The period witnessed...`复杂而少收益。不要把p8随机CO2演示数字混入10.15真实CO2题。无时间标签时按题干实际语境决定时态，不机械认为一切有年份都是过去（未来年份是预测）。只有图明确预测才用is projected/expected to，不能自行预测。

连接词遵循关系：while/whereas做比较；however/by contrast转折；meanwhile可以转到同时期另一序列；on the contrary用于反驳前述命题，不是万能对比。At first常暗含后来变化，流程第一步用Initially/First更稳。不要每句套Moreover/Last but not least，不需要故作论证。

## 5. 流程图：保留原图顺序，表达物料变化

材料p12–19的核心是阶段、顺序、被动和指代；补充：人工加工常用被动，植物生长/自然循环可用主动；并非必须多用定语从句。先判线性还是循环、输入输出、分支合流、图中编号。流程图不只数步骤，overview还应概括起终点和主要阶段。编号已给时照图，未编号不要因合并方式不同纠缠唯一总步数。

- **制糖p15**：7个编号阶段。甘蔗生长12–18个月→机器或手工收割（并列可选路径）→压榨出汁→石灰石滤器净化→蒸发器加热成糖浆→离心机分离糖晶体→干燥冷却成糖。p16原文第三段、overview及末段有截断。`sugar cane`常作不可数作物，`sugar canes ... it takes`指代乱，可改`Sugar cane is grown for 12 to 18 months before being harvested.`不把种植/储运包装等图外环节补进。句型微练：用either...or...说两种收割方式；用is used to说滤器作用。
- **方便面p17**：8个编号阶段。面粉进入储存筒仓→加水和油混合→滚压面片→切条→做成面饼→油中烹煮并干燥→入杯加蔬菜和调味料→贴标密封。p18范文截断；`taken by cars`应是运粉车辆/卡车而非小汽车；cooking/drying属于加工，不能在这一步就泛称packaging。图中8阶段是以标号为准，水油加入点和蔬菜加入点不得调换。微练：3句写mix→roll→cut，保持物料代词清楚。
- **塑料瓶回收p19**：9个编号阶段，压碎后清洗是阶段5内的附加动作，勿漏洗。投回收桶→收集运输→分拣（有不合格分支）→压块→粉碎和清洗→制塑料颗粒→加热形成原料→原料→制新产品（瓶、衣物、袋、笔等）。图画有产品返回回收端箭头，可说产出新物品、其中瓶可再次进入循环；不能断言所有末端产品均循环同样路径、或全部塑料均可回收。微练：把「压碎/清洗/制粒」用after被动分词衔接。

过程词等号修正（p14）：wind与unwind是相反动作；remove不一定丢弃，dispose of才处置；grind/mill/crush粒度与工具不同，依图选；manufacture不等于become；pour是倾倒液/粉，add是加入，不能同词性机械替换；主动`passes through`与被动`is passed through`按物料和机械动作选择。

## 6. 地图：位置、功能与时间的变化

材料p20–26要求按空间推进，抓新增、移除、替换；补充：没变但帮助建立参照的入口、主要道路或保留花园可以选择写，不能把「不变不必写」当禁令。图上没有北箭头时优先left/right/upper/lower/to the left of the entrance，不能自造地理方向。仅因改造不能写improved significantly，除非能客观具体说明用途变了；不要补原因、体验、经济收益。题图无比例尺，不自造米数或面积翻倍。

- **City Hospital p21**：明确北箭头；2007→2010全是过去。Hospital Road两侧原各3个巴士站，共6个，改为道路西侧的bus station；车站接入医院路南北两端新roundabouts；原医院路东侧共用停车场变为staff only；public car park新增在医院/环路东侧，直接接Ring Road。overview可概括公交、交叉口和停车重新组织，非医院主体扩大。p22范文段落截断，不把未显示结尾当已存在。
- **Library p23**：20年前→today，过去与现在/现在完成时协调；无北箭头。入口仍位于底部中间；中间桌椅被移走。左下阅览室→电脑室；左上CD/视频/游戏→儿童小说和讲故事区域、加沙发；左中成人小说→全部参考书。右上儿童图书→讲座室；右下咨询台→咖啡馆；右中成人非虚构书→成人小说+信息台+自助机。可以概括新增数字、自助、活动与咖啡设施，同时阅读区域重新安排；不能称四个房间「显著改善」作为事实；也不能说参考书消失或成人图书全移除。p24范文截断。
- **Grange Park p25**：1920→today；无指南针，采用左/右或邻接Arnold Avenue与Eldon Street。左侧音乐舞台→大型露天音乐剧场；中央喷泉→玫瑰园，座位围绕；右上水生植物池→儿童游乐区；其左侧原玫瑰园处新增咖啡馆；右下温室→水景，右侧新增地下停车场入口；左上玫瑰园保留、原左右边缘散布座位重布至中央；两条街道上的原人行入口保留。不能凭图认定地下停车场整体面积/入口隶属哪条街；图仅定位右侧偏下入口箭头。

方位表修正（p20/p26）：`in the north of`指范围内部，`to the north of`指相对北侧，不等于一定远离/不接壤；`on the northern boundary of`才清楚边界。`be in close to`错误，改`be close to`；`just off the road`指离路不远/有短接路，不等于所有near。`relocated`搬到新地点，`removed`移除；`give way for`改`give way to`，或make way for；`opposite`通常直接接名词；`expanded`表面积/规模变大，developed泛指开发不必变大。A replaced by B是替换，A converted into B是现有对象改用途，不能一律混用。

## 7. 批改返回格式与纠错优先级

先一句评价任务是否抓对（附图上依据），随后最多3个优先问题。事实错误优先于语言：把人均写总量/时间写次数；丢overview；遗漏峰值；乱组；再修主语一致、连接词、搭配。给最小必要改稿与1个可复用规则，最后给一个短重写任务。若用户索要整篇润色，可给保留其选择与结构的完整版本，标出任何为了事实必须变动之处；不要凭空添加社会原因。

推荐首轮：CO2 overview；第二轮：瑞典峰值句与UK对比；第三轮：电话图迁移和单位；第四轮：流程中间三步；第五轮：地图两组变化。每轮根据实际作答决定是否升级，不预设该用户已经掌握。本批未提供可靠的原作者完整标准答案；本知识库的参考答案均为教练依据原图补写，不能标成教师原答案或官方范文。
