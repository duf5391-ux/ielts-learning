# 语法教学与原练习教师钥匙

本册精读6份材料：5份专项练习（合计54个题位）和9。24课堂笔记。完整逐题中文/英文原题、教师版修正、可接受变体、原因与原文块号在`../data/grammar-items.json`；按id只载入本次3–5题，不把整套答案输出给学生。答案由教练补写，原件没有成套答案；《从句改错练习》B30确有B29的一条合并改正。原始题位中的社会、健康、教育断言只是语言练习命题，未经事实研究，不可当科普结论或Task2现成证据。

## 老师教学主线与迁移

9。24笔记从`cat drinks water`与`cat looks cute`区分动词宾语和系动词表语，接着用「政府投资有利教育」提醒：一个带限定时态的完整主谓句不能直接裸当另一个句子的主语。可改动名词`Investing ...`、名词短语`Adequate government funding ...`或完整名词性从句。之后练名词的形容词、定语从句、-ing/-ed和介词修饰。这条主线正好通向小作文中的`the number/proportion of ...`以及口语中的人物、经历描述。

教学时先找句子骨架，后扩展：
1. 主语核心是谁/什么？例如`the number`不是靠近谓语的cars。
2. 真正的主句谓语在哪里？`who live with their parents`只修饰young people，不能另加they再造重复主语。
3. 修饰里的名词是动作发出者还是承受者？`people using...`与`money spent...`；不是看到汉语「的」一律-ing。
4. 连接词后是完整从句还是名词？because/although/if + 从句；because of/due to/despite + 名词或-ing；with名词、as主谓。
5. 完整和准确后再增加一种可迁移变体。长句本身不等于高分；用户说得出的正确短句可保留。

## 题库全覆盖路由

| 原件 | 覆盖 | 推荐首轮 | 迁移目标 |
|---|---|---|---|
| 强化4+3句子翻译练习.docx | G43-01–06，原文实际6题，不能因标题4+3补造第7题 | 02/03/06 | there be数量、条件被动、社区where、技能过去分词 |
| 修饰名词翻译练习.docx | GMOD-01–10；03必须从句/分词各译1次 | 01/03/08 | 人物定语、钱被花、两组人平行比较 |
| 从句改错练习.docx | GCLA-01–16，14包含错误B29及原修正B30 | 01/06/11 | without/if、重复主语、because/due to |
| 词性改错练习.docx | GPOS-01–12 | 02/07/12 | 动词副词、名词形容词、主语名词化、need to do |
| 主语多样性练习.docx | GSUB-01–10，另有187条手写Ink轨迹 | 02/03/04 | 动名词主语、whether陈述语序、what从句 |
| 9。24.docx | B1–118全部；结构、审题、衔接、PEEL、句法、改写、学习计划 | 依当前问题择取 | 思路与语言分开检查，不当完整Task2课程 |

练习逐题目的：
- G43：01因果双句，02将来条件与there be，03地点定语，04数量差异，05比例与年龄，06被动修饰。
- GMOD：01 who/ing，02 whose，03 that is spent/spent，04 number-to-number比较，05 between与prejudice against，06年龄后置但语义歧义需看图，07 working as，08 those指代比较，09 who want/by visiting，10 who do not/believe that。
- GCLA：01 if/without，02宾语从句缺主语，03 what主语，04 if缺主语，05主从边界，06重复主语，07because句子碎片，08逗号that误接，09who缺谓语，10after的两种结构，11due to接错从句，12whether两选项，13被动漏is，14主语片段，15as/with，16what误作有先行词的关系词。
- GPOS：01obvious/obviously，02dramatic/dramatically，03increasing/increasingly，04significant/significantly，05true/truly及自然程度副词，06health/healthy，07happy/happiness，08positive与happiness，09because/because of/greatly，10replaced/instead of，11with+incredibly+convenient，12communicate/communication。
- GSUB：01被修饰复数主语，02动名词单数，03whether，04what，05it形式主语，06长动名词，07people who，08consumption抽象名词，09lack抽象名词，10people who+两个并列谓语。

## 原件手写内容与可靠边界

《主语多样性练习》并非纯文字文件：OOXML有187个Word Ink对象，位于`word/ink/ink1.xml`等。已从InkML坐标与原OOXML位置恢复轨迹并视觉查看，内部证据图为`工作/writing-grammar/subject-ink.png`；复用图为`../assets/grammar-subjects-ink.png`。这是原手写轨迹重绘，不宣称是Word原分页截图。原件属性显示1页但不可据此担保渲染分页。

可清楚辨认的手写片段集中在前5题：`easy to suffer from obesity`；children/spend/free time/...games/are more等主语展开；`every child a chance to receive...would cost much money`；`tear down = demolished`；`what ... should do ... impose ... on`；`It is impossible for gov...`。许多词是速记曲线，不能伪造完整转录；也无法仅凭笔迹确认是老师还是学生。可用来理解训练意图，不能直接当标准答案。`be more likely to suffer from obesity`比`be easy to suffer...`自然；`tear down`与`demolish`词义对应但形态需匹配，`be torn down`= `be demolished`。

## 9。24笔记逐层消化

### 审题和组织（B9–48）

材料把同不同意、双方讨论、两问分成段落框架，目的在让每段对应任务；`主办国`例很好地展示了限定词：论证世界和平若不连接主办国获益就偏离范围。不能把所有agree/disagree都要求完全同意、所有优缺点都等同discuss both views；必须看原题是否问outweigh、degree或own opinion。Task2叫Task Response，Task1叫Task Achievement，不能一概TA。

材料的城市物价→赚钱压力→兼职/加班→没空外出是因果链训练；补充要用can/may避免把单一解释说成人人必然。PEEL的价值是让观点有机制与具体例证；各句不必机械标P/E/E/L。动物节目例中的`which are not covered in books / taught in schools`过强，可改`which may not be covered in their school lessons`，若没有依据就不要比较覆盖绝对范围。`beneficial education tool`改`a useful educational tool`。

衔接不是只换连接词：先后事项共享人物，用代词明确回指，再用逻辑关系连接。小明例增加「聊旧事」使从见面到成为朋友有中间机制，这比硬插therefore更关键。迁移口语Part3：一个回答先给立场，再说「为什么/怎样起作用」，举一具体情境即可，不一定写作文式收束。

### 句法和词块（B50–84）

- `government invests enough money is beneficial...`有两个未连接的限定谓语；可`Investing enough money in education is beneficial...`，但主语泛化；更精确`Adequate government funding can support educational development.`这是新写自然版本，不是原文。
- `the government do not`：英式把government视集体可用复数，但学生基础阶段统一机构单数`the government does not`更容易保持一致；不能笼统称英式复数一律语法错。
- `because the government does not invest enough money`与`due to inadequate government funding`展示句/短语转换。`due to the fact that...`可成立但累赘，不要当高级必用句。
- `cars which use clean energy`→`cars using clean energy`是主动缩减；`money spent on...`是被动缩减。`desired goals`语法可行但语义略重复；按语境用desired outcomes更自然。
- `people against animal experiment`至少用`animal experiments`或`animal testing`；`people who oppose animal testing`比disagree with animal experiment搭配稳。
- `Because ...`在此正式写作语境是从句，不能独立成句；口语短答因为对话可省略主句，不应把课堂写作规则无限扩大到所有话语。

### 改写与观点（B88–108）

`an increasing number of people...`不等于`...has become a common practice`：前者趋势上升，后者广泛普遍；不能机械互换。`on traditional styles`改`in traditional styles`。公共交通题原有best、government、free、24/7，任何改写不能漏most effective或7 days a week；主动被动转换不是忽略限定词的许可。

`This essay will explain...`是可用信号，不是必须背的开头；真正观点必须清楚。讨论大学与技术工种时，「取决于xxx」未完成，不构成充分的个人立场，需补取决于兴趣、能力、职业目标等具体标准并展开。`skilled professionals`范围可能比skilled workers宽，保留题目关键人群更稳；不能用换词作掩护改变对象。

### 时间与学习计划（B1–6、B110–118）

记录的「大作文40–45分钟、小作文15–20分钟」是课堂安排，考试总写作时间与官方建议以官方核实文件为准；不能45+20超过总时长仍当推荐。12月底6.5、538两轮、逻辑链背熟、每日练习时长是历史笔记，不是本用户当前承诺、成绩保证或已完成记录。不要据此创建学习档案中的考试日期/目标分数。

## 三种可立即使用的练习闭环

**问题驱动纠错**：用户句子`Despite the gap narrowed, ...`→先问他保留despite还是换although（可直接给一个小选择题）→用一个非当前答案的例子说明两结构→让他重写原句→再改成「Despite + 名词化」做迁移。用户只要直接修改时不强行变成问答。

**3题诊断**：每次取GCLA-06、GPOS-02、GSUB-03各1题；不贴答案。收到后标「正确/可接受/需改」；只解释失败的核心结构，再选同类型1题复测。不要因这一轮对了便声称已掌握全部语法。

**写作迁移**：用户改好`a dramatic increase`后，要求把手机图句写为动词版和名词版；改好`number...is`后，用`figures...are`做对照。语法训练应回到用户稿件，避免无限孤立翻译。

推荐反馈：先保留正确骨架；最小必要修改；说明结构关系；给一个自然但不强制采用的替代版本；最后一题新迁移。答案库中的variant若改变了程度或比较范围，必须读boundary，不可当同义答案盲收。
