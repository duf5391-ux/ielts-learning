# Task 1 可迁移语料52条

本册共52条：图表33条、流程10条、地图9条。T01–T32保留原编号并逐条扩充，T33–T52为本轮新增。每条提供含义、适用条件、句架、例句、可换内容、用法要点、短练习、教师参考和来源。

讲义式教学按当前题目的顺序选卡，逐句写出答案并解释选点、词法、句法与承接。用户选择自己练习时，先给题面，收到作答后使用教师参考。核心卡片优先用于自然、准确的表达；提升卡片按句子需要选取。

结构化版本见[task1-language.json](../data/task1-language.json)。原材料M08指《小作文讲义.pdf》，M10指《10.15写作.docx》；页码为物理页，B为正文块号。原图数据沿用精读核查，新增数值和示意场景在各卡明确标为教练自拟。全部例句由教练编写，来源条目支持所列义项或语法规则。

## 趋势走向组合索引

先定位时间区间和数量主语，再把方向、幅度或速度、转折和收尾接在一起。下面8种组合可直接按图取用；对应卡片提供完整解释和迁移练习。

| 走势 | 可直接替换的句架 | 相关卡片 |
|---|---|---|
| 持续上升 | `[quantity] rose/increased [adverb] from A to B.` | T04、T06、T38 |
| 持续下降 | `[quantity] fell/declined [adverb] from A to B.` | T04、T06、T38 |
| 先升后降 | `[quantity] rose from A to a peak of B before falling to C.` | T07 |
| 先降后升 | `[quantity] fell to a low of B before rising again to C.` | T41 |
| 上升后趋稳 | `[quantity] rose to B and then levelled off at that level.` | T39、T08 |
| 下降后趋稳 | `[quantity] fell to B and then remained stable at that level.` | T39、T08 |
| 反复波动 | `[quantity] fluctuated between A and B over [period].` | T40 |
| 整个所述区间稳定 | `[quantity] remained broadly unchanged at A throughout [interval].` | T08、T36 |

方向动词可先用rise/increase、fall/decrease。climb常用于上升数值，grow常用于人口、产量、消费等增长；decline适合下降，drop可配slightly或sharply来说明幅度。搭配的词形随句法选择：`rose sharply`对应`a sharp rise`，`fell gradually`对应`a gradual fall`。

程度选择依图而定：`slightly`呈现小幅变化；`considerably`呈现较大幅度；`rapidly`呈现较快进程；`gradually`呈现逐步进程；`steadily`呈现持续而较均匀的变化。每句选取能由曲线与坐标共同支持的描述。

**持续上升**：Portugal’s figure rose from about one tonne per person in 1967 to roughly 5.5 tonnes in 2007.  
选用依据：选择rise/increase呈现方向，再根据幅度和时间进程加slightly、considerably、gradually等修饰。 示例依据：本批CO2图。

**持续下降**：The UK figure fell gradually from just under 11 tonnes per person in 1977 to just under nine in 2007.  
选用依据：把起止区间写清，fell/declined与下降方向对应。 示例依据：本批CO2图1977–2007段。

**先升后降**：Sweden’s figure rose to a peak of just over ten tonnes per person in 1977 before falling to around 5.5 in 2007.  
选用依据：起点、峰值、终点依时间排列；peak at和a peak of分别对应动词与名词结构。 示例依据：本批CO2图。

**先降后升**：The figure fell from 40 to a low of 20 before rising again to 35.  
选用依据：先定位最低点，再写回升方向与终点；return to its initial level可说明回到原水平。 示例依据：自拟练习数据。

**上升后趋稳**：Italy’s figure rose to just under eight tonnes per person in 1997 and then levelled off.  
选用依据：先写到达的平台值，再用levelled off或remained broadly stable接平台段。 示例依据：本批CO2图。

**下降后趋稳**：The figure fell from 60 to 40 and then remained stable at that level.  
选用依据：下降动词交代前段，平台表达交代后段，共享同一数量主语。 示例依据：自拟练习数据。

**反复波动**：The figure fluctuated between 20 and 30 over five months.  
选用依据：按连续观测点识别多次上下变化，再用上下限概括波动区间。 示例依据：自拟序列20、30、22、28、21。

**整个所述区间稳定**：The UK figure remained broadly unchanged at just under 11 tonnes per person between 1967 and 1977.  
选用依据：明确稳定区间；broadly适合图上轻微变化。 示例依据：本批CO2图首十年。

## 按功能取用

- 数值与起终点：T01–T05、T14、T33、T35、T37、T47。
- 方向、幅度、速度和转折：T04、T06–T09、T13、T38–T41。
- 排序、差距、份额和倍数：T10–T17、T34、T42–T46。
- 时间与预测：T18、T36。
- 流程顺序、处理、分支和循环：T19–T26、T48–T49。
- 地图位置、用途、扩建与通达：T27–T32、T50–T52。

CO2全文示范优先取T02、T33、T34、T35、T36以及T07、T39。选中具体句子后，依次讲“这句报告哪个点→怎样表达数量→怎样接下一句”。

## 逐条卡片

### T01 compare X in terms of Y（图表·核心）

- **精准含义**：按同一指标比较对象。
- **适用条件**：引言需要同时交代比较对象和衡量指标。
- **句架槽位**：The chart compares [objects] in terms of [measured variable] between [year A] and [year B].
- **自然例句**：The graph compares four countries in terms of average CO2 emissions per person between 1967 and 2007.
- **例句依据**：教练依据本批原图自写
- **可换内容**：objects→countries / age groups / modes of transport；variable→water consumption / average journey time
- **用法要点**：in terms of后接名词短语；the graph作单数主语配compares。按题图保留average、total、per person及单位。
- **短练习**：用这条句架介绍英国1995–2002年三类通话总时长。
- **教师参考**：The chart compares three categories of telephone calls in the UK in terms of their total duration between 1995 and 2002.
- **评价点**：对象、总时长、地点和年份齐全；单位可在下一句说明。
- **来源与归属**：M08:p3；M10:两张题图。原材料教学主题保留；义项、使用条件、句架和练习经本轮编辑扩充。T01–T32沿用原ID；外部核验：[S01](#source-s01)。

### T02 average ... per person / per-capita ...（图表·核心）

- **精准含义**：每人的平均值；per-capita作前置修饰语。
- **适用条件**：题干或纵轴标明每人平均量。
- **句架槽位**：average [emissions/consumption] per person in [place]；per-capita [emissions/consumption]
- **自然例句**：Average CO2 emissions per person in the UK remained higher than those in the other three countries.
- **例句依据**：教练依据本批原图自写
- **可换内容**：emissions→water consumption；per person→per household，依据题图分母选择
- **用法要点**：emissions配复数谓语和those；consumption配单数谓语和that。per-capita放在名词前；per person放在指标后。
- **短练习**：用“每户平均用水量”写一个完整名词短语，并说明它的分母。
- **教师参考**：average water consumption per household；分母是家庭户数。
- **评价点**：保留average与per household；量和分母对应。
- **来源与归属**：M10:image1；M08:p7。原材料教学主题保留；义项、使用条件、句架和练习经本轮编辑扩充。T01–T32沿用原ID。

### T03 the total duration of ...（图表·核心）

- **精准含义**：某类活动累计持续的时间。
- **适用条件**：图表用分钟、小时等单位累计时长。
- **句架槽位**：The total duration of [activity] rose/fell to [value + time unit] in [year].
- **自然例句**：The total duration of mobile calls rose to about 45 billion minutes in 2002.
- **例句依据**：教练依据本批原图自写
- **可换内容**：activity→mobile calls / journeys；time unit→minutes / hours，按图选择
- **用法要点**：duration作单数主语；45 billion minutes中billion保持原形、minutes用复数。图中的类别名与时间单位一起保留。
- **短练习**：用the total duration of写2002年本地固定电话约720亿分钟。
- **教师参考**：The total duration of local fixed-line calls was about 72 billion minutes in 2002.
- **评价点**：72 billion与720亿对应；保留local fixed-line。
- **来源与归属**：M10:image2、B27–33。原材料教学主题保留；义项、使用条件、句架和练习经本轮编辑扩充。T01–T32沿用原ID。

### T04 rise/fall from A to B（图表·核心）

- **精准含义**：从起始水平升到或降到终点。
- **适用条件**：有两个明确的时间与数值，需要概括变化方向。
- **句架槽位**：[quantity] rose/fell from [initial value] in [year A] to [final value] in [year B].
- **自然例句**：Portugal’s figure rose from about one tonne per person in 1967 to roughly 5.5 tonnes in 2007.
- **例句依据**：教练依据本批原图自写
- **可换内容**：rose→increased / climbed；fell→decreased / declined；主体→the figure for X / the number of X
- **用法要点**：rise–rose–risen；fall–fell–fallen。from连接起点，to连接终点；两个数值使用同一单位。
- **短练习**：手机通话从1995年约30亿分钟增至2002年约450亿分钟，写一句。
- **教师参考**：Mobile call duration rose from about three billion minutes in 1995 to roughly 45 billion in 2002.
- **评价点**：方向、年份、两个数值及单位对应；rise的过去式rose。
- **来源与归属**：M08:p4、p8；M10:image2。原材料教学主题保留；义项、使用条件、句架和练习经本轮编辑扩充。T01–T32沿用原ID；外部核验：[S01](#source-s01)。

### T05 increase by A / increase to B（图表·核心）

- **精准含义**：by引出增量；to引出到达的水平。
- **适用条件**：需要报告增幅，或把终点与增量放进同一句。
- **句架槽位**：[quantity] increased by [difference] to [final value].
- **自然例句**：The number of visitors increased by 20,000 to 60,000.
- **例句依据**：教练自拟数值，供结构练习
- **可换内容**：increase→rise / decrease / fall；单位→people / tonnes / pounds
- **用法要点**：先用终点减起点计算增量，再把结果放在by后。下降幅度用正数表达：fell by 20,000 to 40,000。
- **短练习**：某值从40增至60，用by和to写一句。
- **教师参考**：The figure increased by 20 to 60.
- **评价点**：by后20，to后60；如原图有单位，句中补齐。
- **来源与归属**：M08:p8起终点结构；本轮补量差用法。原材料教学主题保留；义项、使用条件、句架和练习经本轮编辑扩充。T01–T32沿用原ID。

### T06 a sharp/gradual/slight rise in ...（图表·核心）

- **精准含义**：某指标急剧、逐渐或小幅上升。
- **适用条件**：需要将动词趋势句转换为名词趋势句，或强调变化特征。
- **句架槽位**：There was a [adjective] rise/fall in [quantity]. / [quantity] rose/fell [adverb].
- **自然例句**：There was a sharp fall in Sweden’s per-capita emissions after 1977.
- **例句依据**：教练依据本批原图自写
- **可换内容**：sharp/sharply；gradual/gradually；slight/slightly；steady/steadily
- **用法要点**：形容词放在rise/fall前，副词修饰rose/fell。gradual呈现逐步变化，slight呈现小幅变化；按曲线的时间进程和幅度分别选择。
- **短练习**：将Mobile call duration rose sharply.改成There was句。
- **教师参考**：There was a sharp rise in mobile call duration.
- **评价点**：a sharp rise in完整；名词rise前用sharp。
- **来源与归属**：M08:p5、p8；M10:image1–2。原材料教学主题保留；义项、使用条件、句架和练习经本轮编辑扩充。T01–T32沿用原ID；外部核验：[S01](#source-s01)、[S13](#source-s13)。

### T07 peak at ... before falling to ...（图表·核心）

- **精准含义**：先到达峰值，随后下降到某水平。
- **适用条件**：曲线在中间时点出现最高点，再往下走。
- **句架槽位**：[quantity] rose to a peak of [value] in [year], before falling to [endpoint]. / [quantity] peaked at [value].
- **自然例句**：Local fixed-line call duration peaked at around 90 billion minutes in 1999 before falling to about 72 billion in 2002.
- **例句依据**：教练依据本批原图自写
- **可换内容**：peak at X↔reach a peak of X；fall→decline / drop；时间→in 1999 / midway through the period
- **用法要点**：动词peak接at；名词a peak接of。before后用-ing衔接同一主体的下一段变化。加上起点可写rose from A to a peak of B before falling to C。
- **短练习**：用8.5、略高于10、约5.5吨写瑞典1967→1977→2007的走势。
- **教师参考**：Sweden’s figure rose from about 8.5 tonnes in 1967 to a peak of just over ten in 1977, before falling to roughly 5.5 in 2007.
- **评价点**：三个点按时间排列；peak对应1977；before后用falling。
- **来源与归属**：M08:p5、p9；M10:B33。原材料教学主题保留；义项、使用条件、句架和练习经本轮编辑扩充。T01–T32沿用原ID；外部核验：[S01](#source-s01)。

### T08 remain broadly unchanged / stable（图表·核心）

- **精准含义**：在指定时段大致保持稳定。
- **适用条件**：所述区间数值相同或变化很小。
- **句架槽位**：[quantity] remained broadly unchanged at [value] from [year A] to [year B].
- **自然例句**：Italy’s figure remained broadly unchanged at just under eight tonnes per person from 1997 to 2007.
- **例句依据**：教练依据本批原图自写
- **可换内容**：remain→stay；broadly unchanged→relatively stable；at后→数值区间
- **用法要点**：remain/stay后用形容词；broadly/relatively容纳图上轻微变化。把稳定区间的起止年份写清。变化后进入平台可取T39。
- **短练习**：用Italy 1997–2007的数据写稳定段。
- **教师参考**：The figure for Italy remained broadly stable at just under eight tonnes per person between 1997 and 2007.
- **评价点**：平台区间和约数准确；remain后stable。
- **来源与归属**：M08:p5；M10:image1。原材料教学主题保留；义项、使用条件、句架和练习经本轮编辑扩充。T01–T32沿用原ID；外部核验：[S09](#source-s09)、[S10](#source-s10)。

### T09 return to its initial level（图表·核心）

- **精准含义**：经历变化后回到初始水平。
- **适用条件**：中间有明显起伏，终点与起点接近。
- **句架槽位**：[quantity] returned to approximately its initial level by [year].
- **自然例句**：By 2002, local call duration had returned to approximately its 1995 level.
- **例句依据**：教练依据本批原图自写
- **可换内容**：initial level→previous level / starting point；returned→fell back / recovered，按方向选择
- **用法要点**：by给出观察截止点；had returned把回到起始水平这一过程放在该点之前。简单过去时returned同样可用于按时间顺序报告。
- **短练习**：写本地电话1995约72、1999约90、2002约72的一句概括。
- **教师参考**：Local call duration rose to around 90 billion minutes in 1999 and then returned to approximately its initial level by 2002.
- **评价点**：呈现先升、再回落；initial指1995。
- **来源与归属**：M10:B33；M08:p9。原材料教学主题保留；义项、使用条件、句架和练习经本轮编辑扩充。T01–T32沿用原ID；外部核验：[S04](#source-s04)、[S25](#source-s25)。

### T10 while / whereas（图表·核心）

- **精准含义**：连接两组数据的比较关系。
- **适用条件**：同一句需要比较两个对象或两组走势。
- **句架槽位**：[clause A], while/whereas [clause B].
- **自然例句**：The figures for Italy and Portugal rose overall, while those for the UK and Sweden fell.
- **例句依据**：教练依据本批原图自写
- **可换内容**：while↔whereas；也可分成两句，用各自明确的主语
- **用法要点**：while/whereas后接完整分句；those代替复数figures。读者通过两组同维指标理解比较关系。
- **短练习**：用两组数据写电话图overview中的趋势句。
- **教师参考**：The total duration of national and international fixed-line calls and mobile calls increased, while local call duration rose initially and then fell.
- **评价点**：两组走势与完整类别清楚；分句各有主语和谓语。
- **来源与归属**：M08:p6、p10；M10:B4。原材料教学主题保留；义项、使用条件、句架和练习经本轮编辑扩充。T01–T32沿用原ID；外部核验：[S01](#source-s01)。

### T11 remain the highest/lowest（图表·核心）

- **精准含义**：在整个指定区间持续处于最高或最低位置。
- **适用条件**：所有相关时点的排名都一致。
- **句架槽位**：The figure for [object] remained the highest/lowest throughout [period].
- **自然例句**：The figure for the UK remained the highest throughout the period.
- **例句依据**：教练依据本批原图自写
- **可换内容**：the highest→the lowest / the second highest；object→country / category
- **用法要点**：最高级前用the；throughout把排名范围覆盖到整个时段。单一时点的排名可写was the highest in [year]。
- **短练习**：写电话图中本地固定电话全期的时长排名。
- **教师参考**：Local fixed-line calls recorded the greatest total duration throughout the period.
- **评价点**：排名依据是总时长；throughout覆盖1995–2002。
- **来源与归属**：M08:p9；M10:B4、B31。原材料教学主题保留；义项、使用条件、句架和练习经本轮编辑扩充。T01–T32沿用原ID；外部核验：[S06](#source-s06)。

### T12 the gap between A and B narrowed/widened（图表·核心）

- **精准含义**：两项数值的差距缩小或扩大。
- **适用条件**：比较两项同单位指标在前后时点的差值。
- **句架槽位**：The gap between [A] and [B] narrowed/widened over [period].
- **自然例句**：The gap between the highest and lowest per-capita emission figures narrowed considerably.
- **例句依据**：教练依据本批原图自写
- **可换内容**：gap→difference；narrowed→widened；A/B→highest/lowest figures 或两个具体对象
- **用法要点**：between后明确两个比较项；差值的单位随指标。先核前后差值，再选择narrow/widen。
- **短练习**：用CO2图概括最高与最低数值间的差距。
- **教师参考**：The gap between the highest and lowest figures narrowed from roughly ten tonnes per person to around 3.5 tonnes.
- **评价点**：比较的是最高与最低；约数保留原图估读精度。
- **来源与归属**：M08:p11；M10:B3–6。原材料教学主题保留；义项、使用条件、句架和练习经本轮编辑扩充。T01–T32沿用原ID；外部核验：[S01](#source-s01)。

### T13 overtake / exceed（图表·提升）

- **精准含义**：overtake表示在变化过程中超过；exceed表示某值高于另一个值。
- **适用条件**：图上有排名交叉，或需要描述数值大小关系。
- **句架槽位**：By [year], A had overtaken B. / A exceeded B by [difference].
- **自然例句**：By 1997, Italy’s figure had overtaken Sweden’s.
- **例句依据**：教练依据本批原图自写
- **可换内容**：A/B→两项同一指标；overtaken→surpassed，需有交叉依据
- **用法要点**：overtake–overtook–overtaken；by 1997说明到该标注年已完成超过。Sweden’s省略重复的figure。exceed可直接接比较对象。
- **短练习**：意大利1987年略低于瑞典、1997年已更高，用by写一句。
- **教师参考**：By 1997, Italy’s per-capita emission figure had overtaken Sweden’s.
- **评价点**：截止时点1997；两个对象都比较人均排放。
- **来源与归属**：M08:p5；M10:image1。原材料教学主题保留；义项、使用条件、句架和练习经本轮编辑扩充。T01–T32沿用原ID；外部核验：[S25](#source-s25)。

### T14 about / just under / just over（图表·核心）

- **精准含义**：大约；略低于；略高于一个参照数值。
- **适用条件**：刻度与曲线之间需要用约数定位。
- **句架槽位**：[quantity] stood at about / just under / just over [value].
- **自然例句**：Italy’s final figure was just under eight tonnes per person.
- **例句依据**：教练依据本批原图自写
- **可换内容**：about→approximately / roughly / around；just under→nearly，适合接近且低于某数
- **用法要点**：about/approximately可表示目标值两侧的近似；just under与just over分别标出下侧和上侧。选择读图能够支持的小数精度。
- **短练习**：7.7和8.2分别用eight为参照写短语。
- **教师参考**：just under eight；just over eight。
- **评价点**：方向对应参照值；两项保持同一单位。
- **来源与归属**：M08:p6；M10:image1。原材料教学主题保留；义项、使用条件、句架和练习经本轮编辑扩充。T01–T32沿用原ID。

### T15 account for / make up X% of Y（图表·核心）

- **精准含义**：某部分占总体的某个比例。
- **适用条件**：图中有份额或可明确确定分母的总量。
- **句架槽位**：[part] accounted for [percentage] of [whole].
- **自然例句**：Food accounted for 30% of household expenditure.
- **例句依据**：教练自拟份额，供结构练习
- **可换内容**：part→transport / food / renewable energy；whole→total spending / electricity generation
- **用法要点**：account for / make up后接份额；of后交代分母。过去年份用accounted/made，当前截面按题干时态选。
- **短练习**：假设交通占家庭总支出的25%，写一句。
- **教师参考**：Transport accounted for 25% of total household expenditure.
- **评价点**：份额25%；总体是家庭总支出。
- **来源与归属**：M08:p4。原材料教学主题保留；义项、使用条件、句架和练习经本轮编辑扩充。T01–T32沿用原ID。

### T16 twice as ... as / twice the figure for（图表·核心）

- **精准含义**：某项是另一项的两倍。
- **适用条件**：同一时点两项数值可以计算出明确倍数。
- **句架槽位**：A was twice as high as B. / A was twice the figure for B.
- **自然例句**：The figure for A was twice that for B, at 40 and 20 respectively.
- **例句依据**：教练自拟数值，供结构练习
- **可换内容**：twice→three times；数值主语→the figure / the amount；twice as much water as用于不可数名词
- **用法要点**：倍数句先确定相同比较单位。as high as比较数值高度；as much water as比较用水量；as many cars as比较车数。
- **短练习**：A有60辆车，B有30辆，用twice as many写一句。
- **教师参考**：A had twice as many cars as B.
- **评价点**：cars可数复数配many；twice对应60÷30。
- **来源与归属**：M08:p11倍数教学。原材料教学主题保留；义项、使用条件、句架和练习经本轮编辑扩充。T01–T32沿用原ID；外部核验：[S22](#source-s22)、[S23](#source-s23)。

### T17 respectively（图表·提升）

- **精准含义**：按照前面对象的排列顺序分别对应。
- **适用条件**：一句中有两项对象和两项数据，顺序清楚。
- **句架槽位**：A and B stood at X and Y, respectively.
- **自然例句**：The 2007 figures for the UK and Portugal were about nine and 5.5 tonnes per person, respectively.
- **例句依据**：教练依据本批原图自写
- **可换内容**：对象可换为国家、类别或两个年份；数值随对象顺序替换
- **用法要点**：respectively常放句末；先列对象A/B，再列数值X/Y。给长类别名配两句也有助于阅读。
- **短练习**：A为60、B为30，写一个带respectively的句子。
- **教师参考**：The figures for A and B were 60 and 30, respectively.
- **评价点**：A→60、B→30对应；单位从题目补入。
- **来源与归属**：M08:p9；M10:image1。原材料教学主题保留；义项、使用条件、句架和练习经本轮编辑扩充。T01–T32沿用原ID。

### T18 be projected/expected to（图表·提升）

- **精准含义**：图中预测某指标将达到某状态。
- **适用条件**：题干或图例明确把数据标为预测。
- **句架槽位**：[quantity] is projected to reach [value] by [future year].
- **自然例句**：The population is projected to reach two million by 2030.
- **例句依据**：教练自拟预测数据，供结构练习
- **可换内容**：projected→expected / forecast；reach→rise to / fall to / remain at
- **用法要点**：is projected to后接动词原形；by引出预计达到该水平的时间点。把预测段与历史段的时间标签对应。
- **短练习**：图例标注2035 projection，人口预计250万，用此结构写一句。
- **教师参考**：The population is projected to reach 2.5 million by 2035.
- **评价点**：预测信号与时间一致；million保持原形。
- **来源与归属**：M08:p6。原材料教学主题保留；义项、使用条件、句架和练习经本轮编辑扩充。T01–T32沿用原ID。

### T19 begin with ... and end with ...（流程·核心）

- **精准含义**：从某阶段开始，以某阶段结束。
- **适用条件**：流程overview需要交代输入或首阶段、输出或末阶段。
- **句架槽位**：The process begins with [noun/-ing] and ends with [noun/-ing].
- **自然例句**：Sugar production begins with growing sugar cane and ends with drying and cooling the sugar crystals.
- **例句依据**：教练依据本批原图自写
- **可换内容**：begin with→start with；末阶段可换packaging / cooling / distribution，按图选择
- **用法要点**：with后用名词或动名词；两个端点用平行结构。线性流程可按首尾概括，循环结构可配T49。
- **短练习**：用方便面图写流程起点和终点。
- **教师参考**：The process begins with flour storage and ends with the labelling and sealing of noodle cups.
- **评价点**：储存起点、贴标封口终点均来自图。
- **来源与归属**：M08:p12–13、p15、p17。原材料教学主题保留；义项、使用条件、句架和练习经本轮编辑扩充。T01–T32沿用原ID；外部核验：[S01](#source-s01)。

### T20 consist of ... stages（流程·核心）

- **精准含义**：由若干阶段组成。
- **适用条件**：图中有清楚编号，或已定义合理的阶段分组。
- **句架槽位**：The process consists of [number] main stages.
- **自然例句**：The manufacture of instant noodles consists of eight numbered stages.
- **例句依据**：教练依据本批原图自写
- **可换内容**：number→图中阶段数；stages→steps；主语→process / production cycle
- **用法要点**：consist of采用主动形式；process单数用consists。图中编号可直接支撑步骤总数；其他图按清楚的分段口径描述。
- **短练习**：制糖图7个编号步骤，用consist of写一句。
- **教师参考**：The sugar production process consists of seven main stages.
- **评价点**：consists与单数process一致；数量7。
- **来源与归属**：M08:p12、p16、p18。原材料教学主题保留；义项、使用条件、句架和练习经本轮编辑扩充。T01–T32沿用原ID；外部核验：[S01](#source-s01)。

### T21 be harvested either ... or ...（流程·核心）

- **精准含义**：作物采用两种可选方式之一收获。
- **适用条件**：图中展示同一阶段的两条替代路径。
- **句架槽位**：[crop] is harvested either by [means A] or by [means B].
- **自然例句**：Sugar cane is harvested either by machine or by hand.
- **例句依据**：教练依据本批原图自写
- **可换内容**：crop→按图所示作物；by machine / by hand；either...or也可连接两种容器或处理方式
- **用法要点**：either与or连接平行结构；by machine与by hand表示方式。两条箭头在此共同对应收割阶段。
- **短练习**：将“甘蔗机械收割或人工收割”写成一句。
- **教师参考**：Sugar cane is harvested either mechanically or by hand.
- **评价点**：替代方式清楚；被动is harvested；也接受either by machine or by hand。
- **来源与归属**：M08:p15–16。原材料教学主题保留；义项、使用条件、句架和练习经本轮编辑扩充。T01–T32沿用原ID；外部核验：[S26](#source-s26)、[S27](#source-s27)。

### T22 be used to + verb（流程·核心）

- **精准含义**：某工具用于完成某个动作。
- **适用条件**：图中机器、装置或工具的功能清楚。
- **句架槽位**：[equipment] is used to [verb] [material].
- **自然例句**：A limestone filter is used to purify the juice.
- **例句依据**：教练依据本批原图自写
- **可换内容**：equipment→a centrifuge / rollers；verb→separate / flatten / filter
- **用法要点**：be used to do在此表达用途，to后用原形。equipment和material分别对应图中装置与物料。
- **短练习**：用离心机和糖晶体写一个功能句。
- **教师参考**：A centrifuge is used to separate sugar crystals from the syrup.
- **评价点**：装置、动作、晶体和糖浆关系完整。
- **来源与归属**：M08:p16。原材料教学主题保留；义项、使用条件、句架和练习经本轮编辑扩充。T01–T32沿用原ID；外部核验：[S26](#source-s26)。

### T23 be passed through ...（流程·核心）

- **精准含义**：物料被送过某个装置。
- **适用条件**：图中箭头显示物料经过设备并发生处理。
- **句架槽位**：[material] is passed through [equipment] to [purpose].
- **自然例句**：The dough is passed through rollers to form sheets.
- **例句依据**：教练依据本批原图自写
- **可换内容**：material→juice / dough；equipment→a filter / rollers
- **用法要点**：受处理物料作被动主语；物料自身流动可写The juice passes through a filter。用图上当前物料名称衔接阶段。
- **短练习**：写甘蔗汁通过石灰石滤器净化。
- **教师参考**：The juice is passed through a limestone filter for purification.
- **评价点**：汁作主语；通过滤器；净化功能。
- **来源与归属**：M08:p14、p15、p17。原材料教学主题保留；义项、使用条件、句架和练习经本轮编辑扩充。T01–T32沿用原ID；外部核验：[S26](#source-s26)。

### T24 be mixed with / be added to（流程·核心）

- **精准含义**：与另一物料混合；加入到某物料或容器中。
- **适用条件**：图中标出辅料添加点或搅拌阶段。
- **句架槽位**：A is mixed with B. / B is added to A.
- **自然例句**：The flour is mixed with water and oil to make dough, which is then rolled into sheets.
- **例句依据**：教练依据本批原图自写
- **可换内容**：A→flour / mixture；B→water / oil / spices；容器→cups / a tank
- **用法要点**：mixed with连接混合成分；added to交代添加物的去向。按加工阶段依次使用flour、dough、sheets等物料名。
- **短练习**：用vegetables and spices与cups写方便面加料步骤。
- **教师参考**：Vegetables and spices are added to the cups containing the dried noodles.
- **评价点**：添加物作复数主语are；to后为杯子；干燥已完成。
- **来源与归属**：M08:p14、p17–18。原材料教学主题保留；义项、使用条件、句架和练习经本轮编辑扩充。T01–T32沿用原ID；外部核验：[S26](#source-s26)。

### T25 after being ... / once ... has been ...（流程·提升）

- **精准含义**：完成前一处理后，进入下一步骤。
- **适用条件**：前后动作共享同一物料，或可用从句明确指代。
- **句架槽位**：After being [past participle], [material] is [next action]. / Once [material] has been [action], it is [next action].
- **自然例句**：After being crushed, the plastic is washed and made into pellets.
- **例句依据**：教练依据本批原图自写
- **可换内容**：crushed→dried / sorted / cooled；主句动作按箭头次序替换
- **用法要点**：After being后的动作承受者与主句主语一致。Once从句提供独立主语；has been加过去分词强调前一步已完成。
- **短练习**：把“瓶子压成块，然后粉碎”合成一句。
- **教师参考**：After being compressed into blocks, the bottles are crushed.
- **评价点**：压缩和粉碎的承受者一致；顺序对应图。
- **来源与归属**：M08:p13、p19。原材料教学主题保留；义项、使用条件、句架和练习经本轮编辑扩充。T01–T32沿用原ID；外部核验：[S26](#source-s26)。

### T26 separate A from B（流程·核心）

- **精准含义**：从混合物或来源中分离出某物。
- **适用条件**：流程明确显示分离步骤及其前后物料。
- **句架槽位**：A is separated from B by/in [equipment].
- **自然例句**：Sugar crystals are separated from the syrup in a centrifuge.
- **例句依据**：教练依据本批原图自写
- **可换内容**：A→crystals / solids；B→syrup / liquid，按图选择
- **用法要点**：from引出分离来源；in表示所在设备，by可引出实施分离的装置。分离结果继续作为下一步主语。
- **短练习**：用centrifuge作主动句主语重写例句。
- **教师参考**：A centrifuge separates sugar crystals from the syrup.
- **评价点**：单数centrifuge配separates；from后syrup。
- **来源与归属**：M08:p14–15。原材料教学主题保留；义项、使用条件、句架和练习经本轮编辑扩充。T01–T32沿用原ID；外部核验：[S26](#source-s26)。

### T27 be located to the ... of（地图·核心）

- **精准含义**：位于某参照物的某个方向。
- **适用条件**：地图给出指南针，或选用左右等相对位置。
- **句架槽位**：A is/was located to the [direction] of B.
- **自然例句**：The new public car park was located to the east of the hospital.
- **例句依据**：教练依据本批原图自写
- **可换内容**：east→west / north / south；相对位置→to the left/right of；B→hospital / entrance
- **用法要点**：方向短语中的the保持完整；参照物决定方位的含义。图书馆等平面图可按入口和左右组织。
- **短练习**：以Hospital Road为参照描述新巴士站。
- **教师参考**：The new bus station was located to the west of Hospital Road.
- **评价点**：医院图指南针支持west；参照物Hospital Road。
- **来源与归属**：M08:p20–21、p26。原材料教学主题保留；义项、使用条件、句架和练习经本轮编辑扩充。T01–T32沿用原ID。

### T28 be replaced by（地图·核心）

- **精准含义**：原有设施所在位置改由新设施占用。
- **适用条件**：新旧图展示清楚的同址替换。
- **句架槽位**：A was/has been replaced by B.
- **自然例句**：The fountain has been replaced by a rose garden.
- **例句依据**：教练依据本批原图自写
- **可换内容**：A→fountain / pond / stage；B→rose garden / play area / amphitheatre
- **用法要点**：A放被替换的原物，by后放新物。两个过去年份用was replaced；过去与today对照可用has been replaced。
- **短练习**：将图书馆咨询台变为咖啡馆写一句。
- **教师参考**：The former enquiry desk has been replaced by a café.
- **评价点**：原物与新物位置关系正确；时态对应today。
- **来源与归属**：M08:p20、p23、p25–26。原材料教学主题保留；义项、使用条件、句架和练习经本轮编辑扩充。T01–T32沿用原ID；外部核验：[S26](#source-s26)。

### T29 be converted into（地图·核心）

- **精准含义**：现有建筑或房间改成另一种用途。
- **适用条件**：同一空间在新旧图中显示功能转变。
- **句架槽位**：[former space] has been converted into [new use].
- **自然例句**：The former reading room has been converted into a computer room.
- **例句依据**：教练依据本批原图自写
- **可换内容**：reading room→warehouse / hall；new use→computer room / offices，依图替换
- **用法要点**：into后接新用途的名词。过去时点对比用was converted；过去到现在可用has been converted。
- **短练习**：用图书馆左下房间写一个过去→现在功能句。
- **教师参考**：The room previously used for reading newspapers and magazines has been converted into a computer room.
- **评价点**：原用途和新用途完整；转换主体是房间。
- **来源与归属**：M08:p23、p26。原材料教学主题保留；义项、使用条件、句架和练习经本轮编辑扩充。T01–T32沿用原ID；外部核验：[S30](#source-s30)。

### T30 be removed to make way for（地图·核心）

- **精准含义**：原设施被移除，为新设施腾出空间。
- **适用条件**：规划文字或同址改建信息支持新设施占用原位置。
- **句架槽位**：A was removed to make way for B.
- **自然例句**：The pond was removed to make way for a children’s play area.
- **例句依据**：教练依据本批原图自写
- **可换内容**：removed→demolished，适用于拆除建筑；B按新图用途填写
- **用法要点**：make way for引入新设施；give way to也是固定搭配。单纯叙述同址结果可选T28 be replaced by。
- **短练习**：用同一公园事实写一个同址替换句。
- **教师参考**：The pond was replaced by a children’s play area.
- **评价点**：原池塘与新游乐区对应；替换方向清楚。
- **来源与归属**：M08:p25–26。原材料教学主题保留；义项、使用条件、句架和练习经本轮编辑扩充。T01–T32沿用原ID；外部核验：[S26](#source-s26)。

### T31 be relocated from A to B（地图·核心）

- **精准含义**：同一设施或类别从旧位置移到新位置。
- **适用条件**：两张地图可追踪同一功能或设施的前后位置。
- **句架槽位**：[facility] has been relocated from [old location] to [new location].
- **自然例句**：The adult fiction section has been relocated from the left side of the library to the right.
- **例句依据**：教练依据本批原图自写
- **可换内容**：facility→book section / entrance；location→left/right / upper/lower / east/west
- **用法要点**：from给旧位置，to给新位置；跟踪同一功能后选择relocated。出现全新功能时可写was added或T29 converted into。
- **短练习**：用from/to写图书馆成人小说区的位置变化。
- **教师参考**：The adult fiction section has moved from the left side of the library to the right-hand side.
- **评价点**：同一书区、旧位置和新位置都清楚。
- **来源与归属**：M08:p23、p26。原材料教学主题保留；义项、使用条件、句架和练习经本轮编辑扩充。T01–T32沿用原ID。

### T32 remain in the same position / remain in place（地图·核心）

- **精准含义**：设施位置保留。
- **适用条件**：重要参照物在两张图中持续处于同一位置。
- **句架槽位**：[feature] has remained in the same position.
- **自然例句**：The library entrance has remained in the same position.
- **例句依据**：教练依据本批原图自写
- **可换内容**：feature→entrance / road / rose garden；同义表达→has been retained in its original location
- **用法要点**：挑选能帮助读者理解布局的保留项。过去到现在可用has remained；两个过去年份可用remained。
- **短练习**：写Grange Park左上玫瑰园的保留情况。
- **教师参考**：The rose garden in the upper-left corner has remained in the same position.
- **评价点**：保留项及相对位置正确。
- **来源与归属**：M08:p25–26。原材料教学主题保留；义项、使用条件、句架和练习经本轮编辑扩充。T01–T32沿用原ID；外部核验：[S31](#source-s31)。

### T33 stand at / stood at（图表·核心）

- **精准含义**：某指标在指定时点处于某个数值。
- **适用条件**：主体段引入起点，或静态图报告某项数值。
- **句架槽位**：The figure for [object] stood at [approximation + value + unit] in [year].
- **自然例句**：The UK figure stood at about 11 tonnes per person in 1967.
- **例句依据**：教练依据本批原图自写
- **可换内容**：figure→rate / total / proportion；stood at→was，按句子节奏选择
- **用法要点**：stand–stood–stood；at后接数值。主语名称与题图指标保持一致，下一句可用It承接并写变化。
- **短练习**：用stood at写瑞典1967年约8.5吨人均排放。
- **教师参考**：The figure for Sweden stood at approximately 8.5 tonnes per person in 1967.
- **评价点**：at＋约数＋单位；明确Sweden与1967。
- **来源与归属**：M10:image1；本轮CO2整题示范。本轮教练补充；所列原材料提供教学场景或题图，卡片解释与练习为本轮新写；外部核验：[S02](#source-s02)。

### T34 record the highest/lowest figure（图表·核心）

- **精准含义**：某对象显示出比较范围中的最高或最低数值。
- **适用条件**：把排名与对象放进overview或主体段。
- **句架槽位**：[object] recorded the highest/lowest [figure/rate/total] in [year/period].
- **自然例句**：The UK recorded the highest per-capita emission figures throughout the period.
- **例句依据**：教练依据本批原图自写
- **可换内容**：recorded→had；highest→lowest / second highest；指标可换average consumption / total call duration
- **用法要点**：record作及物动词接指标。一个时点可用figure，多时点各有一项数值可用figures。recorded在此呈现图上记录到的数值。
- **短练习**：写葡萄牙在1967年的人均排放排名。
- **教师参考**：Portugal recorded the lowest per-capita emission figure in 1967.
- **评价点**：最低限定在1967；figure单数；人均指标保留。
- **来源与归属**：M10:B4、image1；本轮CO2整题示范。本轮教练补充；所列原材料提供教学场景或题图，卡片解释与练习为本轮新写；外部核验：[S03](#source-s03)、[S06](#source-s06)。

### T35 the initial/final figure（图表·核心）

- **精准含义**：指定时期的起始值和最终值。
- **适用条件**：描述首末时点，或接续一个已明确的时间范围。
- **句架槽位**：The initial figure for [object] was [A], and the final figure was [B].
- **自然例句**：Portugal’s initial figure was roughly one tonne per person, and its final figure was around 5.5 tonnes.
- **例句依据**：教练依据本批原图自写
- **可换内容**：initial→starting；final→ending；figure→level / value
- **用法要点**：initial和final作形容词修饰figure/level/value。先在前文说明时期，后面用这组词回指两端；原图有多阶段时写清所指区间。
- **短练习**：已说明1967–2007，用initial/final写英国约11吨→略低于9吨。
- **教师参考**：The UK’s initial figure was about 11 tonnes per person, and its final figure was just under nine.
- **评价点**：首末值对应1967/2007；后半句可省已清楚的单位。
- **来源与归属**：M10:image1；本轮CO2整题示范。本轮教练补充；所列原材料提供教学场景或题图，卡片解释与练习为本轮新写；外部核验：[S04](#source-s04)、[S05](#source-s05)。

### T36 throughout the period / over the following decade（图表·核心）

- **精准含义**：贯穿整个时期；在接下来的十年中。
- **适用条件**：需要标明某状态覆盖的全期，或从已提年份推进到下一段。
- **句架槽位**：[state] throughout [period]. / After [reference year/event], [change] over the following decade.
- **自然例句**：The UK had the highest figure throughout the period. Italy reached nearly eight tonnes in 1997 and remained broadly stable over the following decade.
- **例句依据**：教练依据本批原图自写
- **可换内容**：period→40-year period / final decade；following decade→following five years / next ten years
- **用法要点**：throughout表示全程覆盖；the following decade从前文最近的时间锚点向后数十年。名词前保留the；本例1997后的十年为1997–2007。
- **短练习**：已写UK约11吨in1967，接一句说明接下来十年大致稳定。
- **教师参考**：Its figure remained broadly stable over the following decade.
- **评价点**：时间锚点1967，区间1967–1977；It指英国数值。
- **来源与归属**：M08:p8时间段；M10:image1；本轮示范补充。本轮教练补充；所列原材料提供教学场景或题图，卡片解释与练习为本轮新写；外部核验：[S06](#source-s06)、[S07](#source-s07)、[S08](#source-s08)。

### T37 the number/amount of ... / measured in ...（图表·核心）

- **精准含义**：可数对象的数量、物质量，以及图表采用的计量单位。
- **适用条件**：引言或数据句需要明确量纲、计数对象和分母。
- **句架槽位**：the number of [plural count noun]；the amount of [mass noun]；[data] are measured in [units].
- **自然例句**：Water consumption was measured in litres per person per day.
- **例句依据**：教练自拟计量场景，供结构练习
- **可换内容**：number→cars / visitors；amount→water / waste；unit→tonnes / billion minutes / pounds per household
- **用法要点**：the number/amount的核心名词为单数，谓语随核心变化；数词后的million/billion保持原形。per person per day保留人均与每天两个分母。
- **短练习**：图轴标2和3，单位为thousands of cars。先介绍图轴单位，再用完整车数写趋势。
- **教师参考**：The chart shows the number of cars in thousands. Car numbers increased from 2,000 to 3,000.
- **评价点**：原图数值2/3配千辆单位；正文完整车数2000/3000配cars。
- **来源与归属**：M08:p7；M10:两张图的单位。本轮教练补充；所列原材料提供教学场景或题图，卡片解释与练习为本轮新写；外部核验：[S21](#source-s21)。

### T38 rise sharply / rise rapidly / rise gradually（图表·核心）

- **精准含义**：用幅度与时间进程描述增长的形状。
- **适用条件**：图有足够时间点，且坐标尺度清楚，可判断增量和进展速度。
- **句架槽位**：[quantity] rose [adverb] from [A] to [B] over [duration].
- **自然例句**：The figure rose rapidly from 20 to 40 in two years. The same increase occurred gradually over twenty years in the second series.
- **例句依据**：教练自拟两组时间序列，供速度表达练习
- **可换内容**：幅度→slightly / considerably / sharply；速度过程→rapidly / gradually；下降可换fell
- **用法要点**：动词后用副词；名词前用形容词，如a sharp rise、rapid growth。比较速度时同时查看时间跨度与纵轴尺度；比较幅度时查看同单位的起终点差。
- **短练习**：同为20→40，A用2年、B用20年，分别写一句说明过程。
- **教师参考**：A rose rapidly from 20 to 40 over two years. B increased gradually from 20 to 40 over twenty years.
- **评价点**：相同增量、不同耗时表达清楚；用rapidly/gradually修饰动词。
- **来源与归属**：M08:p5趋势程度；本轮按功能重组。本轮教练补充；所列原材料提供教学场景或题图，卡片解释与练习为本轮新写；外部核验：[S01](#source-s01)、[S13](#source-s13)。

### T39 level off at / reach a plateau（图表·核心）

- **精准含义**：变化之后进入一个大致稳定的水平。
- **适用条件**：曲线先升或先降，后段呈平台。
- **句架槽位**：[quantity] rose/fell to [level] and then levelled off. / [quantity] reached a plateau at [level].
- **自然例句**：Italy’s figure rose to just under eight tonnes per person in 1997 and then levelled off.
- **例句依据**：教练依据本批原图自写
- **可换内容**：上升后→rose ... before levelling off at ...；下降后→fell ... and then levelled off at ...
- **用法要点**：level off常作不及物短语动词；数值用at连接。英式levelled/levelling与美式leveled/leveling任选并保持一致。plateau名词配reach a plateau，适合指出平台阶段。
- **短练习**：自拟图：60→40，随后保持40。用下降＋趋稳写一句。
- **教师参考**：The figure fell from 60 to 40 and then levelled off at 40.
- **评价点**：先降后稳的顺序；平台值40；可接受remained stable at 40。
- **来源与归属**：M08:p5稳定；M10:image1意大利；本轮补转折组合。本轮教练补充；所列原材料提供教学场景或题图，卡片解释与练习为本轮新写；外部核验：[S09](#source-s09)、[S10](#source-s10)。

### T40 fluctuate between ... and ... / range from ... to ...（图表·核心）

- **精准含义**：fluctuate描述反复升降；range给出一组数值的上下限。
- **适用条件**：连续时点反复变化可用fluctuate；需要概括多项观测的范围可用range。
- **句架槽位**：[quantity] fluctuated between [low] and [high]. / [values] ranged from [minimum] to [maximum].
- **自然例句**：Monthly demand fluctuated between 20 and 30 units over the year.
- **例句依据**：教练自拟月度序列
- **可换内容**：fluctuated slightly/sharply；ranged from A to B / ranged between A and B；主体→monthly totals / temperatures
- **用法要点**：fluctuate和range在此用主动形式。between搭and；from搭to。反复升降按时间排序确认，范围按最小与最大值确认。
- **短练习**：自拟五个月数值20、30、22、28、21，用一句概括反复变化范围。
- **教师参考**：The figure fluctuated between 20 and 30 over the five months.
- **评价点**：多个上下转折；上下限20/30；单位从给定场景补齐。
- **来源与归属**：M08:p5波动；本轮补范围用法。本轮教练补充；所列原材料提供教学场景或题图，卡片解释与练习为本轮新写；外部核验：[S11](#source-s11)、[S12](#source-s12)。

### T41 reach a low of ... before rising again（图表·核心）

- **精准含义**：先降至低点，随后回升。
- **适用条件**：图中出现低谷，后续值重新上升。
- **句架槽位**：[quantity] fell to a low of [B] in [year] before rising again to [C].
- **自然例句**：The figure fell from 40 to a low of 20, before rising again to 35.
- **例句依据**：教练自拟低谷与回升序列
- **可换内容**：rising again→recovering；恢复到原水平→returning to its initial level；低点→lowest point at [value]
- **用法要点**：a low of后接数值；before后用-ing。recover to可表从低点回升到指定值；用partly/fully和具体数值说明恢复程度。
- **短练习**：自拟2010、2015、2020年分别40、20、35，写一句先降后升。
- **教师参考**：The figure fell from 40 in 2010 to a low of 20 in 2015, before rising again to 35 in 2020.
- **评价点**：低谷在2015；末值35；三个时间点依次连接。
- **来源与归属**：M08:p5最低点；本轮补先降后升组合。本轮教练补充；所列原材料提供教学场景或题图，卡片解释与练习为本轮新写；外部核验：[S01](#source-s01)。

### T42 be followed by / rank second（图表·核心）

- **精准含义**：按数值顺序交代第二项或后续项。
- **适用条件**：同一时间截面需要从大到小组织类别。
- **句架槽位**：A had the highest figure, followed by B at [value]. / B ranked second at [value].
- **自然例句**：In 2007, the UK had the highest figure, followed by Italy at just under eight tonnes per person.
- **例句依据**：教练依据本批原图自写
- **可换内容**：ranked second→ranked third；followed by→with B in second place；对象随排名替换
- **用法要点**：followed by B省略了与前面共享的比较指标；数值紧跟B。先在句中明确年份和指标，再排列对象。
- **短练习**：用2007年CO2图写意大利排名及约数。
- **教师参考**：Italy ranked second in 2007, at just under eight tonnes per person.
- **评价点**：第二名及单位正确；介词at连接数值。
- **来源与归属**：M08:p9静态排序；M10:image1。本轮教练补充；所列原材料提供教学场景或题图，卡片解释与练习为本轮新写；外部核验：[S01](#source-s01)。

### T43 be X units higher/lower than（图表·核心）

- **精准含义**：两项指标相差明确数量。
- **适用条件**：同一时点、同一单位的两项数值可直接相减。
- **句架槽位**：The figure for A was [difference + unit] higher/lower than that for B.
- **自然例句**：In 2007, the UK figure was approximately 3.5 tonnes per person higher than Portugal’s.
- **例句依据**：教练依据本批原图自写
- **可换内容**：higher→lower；单位→tonnes / minutes / percentage points；比较对象→that for B
- **用法要点**：difference前可加about/approximately。figure单数回指用that；figures复数回指用those。百分比数值之差用T44。
- **短练习**：自拟A=80、B=55吨，写A高出多少。
- **教师参考**：The figure for A was 25 tonnes higher than that for B.
- **评价点**：80−55=25；两项均为相同吨数指标。
- **来源与归属**：M08:p9、p11比较；M10:image1。本轮教练补充；所列原材料提供教学场景或题图，卡片解释与练习为本轮新写；外部核验：[S32](#source-s32)。

### T44 an increase of ... percentage points（图表·核心）

- **精准含义**：两个百分比数值之间的差，以百分点计。
- **适用条件**：起点和终点都是百分比，需报告占比变动。
- **句架槽位**：The proportion rose from [A%] to [B%], an increase of [B−A] percentage points.
- **自然例句**：The proportion rose from 40% to 50%, an increase of ten percentage points.
- **例句依据**：教练自拟比例及独立计算
- **可换内容**：rise→fall；percentage points→percentage point，差为1时用单数
- **用法要点**：百分点差＝终点百分比数值−起点百分比数值。相对增幅＝差值÷起点×100%；40%→50%的相对增幅为25%。两种量分别写清名称。
- **短练习**：占比30%→45%，写百分点变化，再算相对增幅。
- **教师参考**：It rose by 15 percentage points, from 30% to 45%. The relative increase was 50%.
- **评价点**：45−30=15个百分点；15÷30=50%。
- **来源与归属**：M08:p4占比；本轮补充数学与语言说明。本轮教练补充；所列原材料提供教学场景或题图，卡片解释与练习为本轮新写；外部核验：[S20](#source-s20)。

### T45 double / halve（图表·核心）

- **精准含义**：增至原来的两倍；减至原来的一半。
- **适用条件**：同一指标前后数值满足明确的倍数关系。
- **句架槽位**：[quantity] doubled from [A] to [2A]. / [quantity] halved from [A] to [A÷2].
- **自然例句**：Water consumption halved from 120 to 60 litres per person per day.
- **例句依据**：教练自拟水量与人数数据
- **可换内容**：doubled→nearly doubled / more than doubled；halved→almost halved；按实际比值选择程度
- **用法要点**：double与halve在此可直接作趋势动词；过去式doubled/halved。to给最终值，from给起点；精确倍数由数值计算支撑。
- **短练习**：访客20,000→40,000，用doubled写一句，并说明增量。
- **教师参考**：The number of visitors doubled from 20,000 to 40,000, an increase of 20,000.
- **评价点**：最终为初始两倍；增量20,000；number作单数核心。
- **来源与归属**：M08:p11倍数；本轮补动态倍数。本轮教练补充；所列原材料提供教学场景或题图，卡片解释与练习为本轮新写；外部核验：[S24](#source-s24)、[S33](#source-s33)。

### T46 together account for ... / the remaining ...（图表·核心）

- **精准含义**：两项合计占某份额；其余部分占剩余份额。
- **适用条件**：类别共同构成同一个总量，适合按大类分组。
- **句架槽位**：A and B together accounted for [combined share] of [total]. The remaining [share] was accounted for by C.
- **自然例句**：Food and housing together accounted for 70% of household spending. The remaining 30% was spent on other items.
- **例句依据**：教练自拟份额图
- **可换内容**：together→combined；other items→明确剩余类别；spending→electricity generation
- **用法要点**：合计前确认类别可相加、分母一致且覆盖关系清楚。the remaining 30%回指前句同一个总体。各部分按图给的分类核总和。
- **短练习**：自拟份额A40%、B35%、C25%，用together与remaining各写一句。
- **教师参考**：A and B together accounted for 75% of the total. C made up the remaining 25%.
- **评价点**：40+35=75；100−75=25；同一总体。
- **来源与归属**：M08:p4、p9份额；本轮补分组写法。本轮教练补充；所列原材料提供教学场景或题图，卡片解释与练习为本轮新写。

### T47 a net increase/decrease of ...（图表·核心）

- **精准含义**：以终点减起点得到的净增量或净减量。
- **适用条件**：图只给两个时间截面，或overview需要概括整个时期的净变化。
- **句架槽位**：Between [year A] and [year B], [quantity] showed a net increase/decrease of [difference].
- **自然例句**：The population showed a net increase of 200,000 between 2000 and 2020.
- **例句依据**：教练自拟两时点数据
- **可换内容**：net increase→net decrease；showed→recorded；quantity→population / total output
- **用法要点**：先比较首末两点计算净差；细节段按图可见时点展开。需要描述过程时，依据中间观测值选择gradually、fluctuated或转折结构。
- **短练习**：自拟某值2000年80、2020年100，图仅给这两点。用net increase写一句。
- **教师参考**：The figure showed a net increase of 20 between 2000 and 2020.
- **评价点**：净增20；年份和单位按题完整表达。
- **来源与归属**：M08:p11两时点图；本轮补净变化句架。本轮教练补充；所列原材料提供教学场景或题图，卡片解释与练习为本轮新写；外部核验：[S01](#source-s01)。

### T48 be divided into ... streams / be either ... or ...（流程·核心）

- **精准含义**：流程在某节点分成数条处理路径，或选择一种处理方式。
- **适用条件**：箭头明确给出分流、替代路径，或后续合流。
- **句架槽位**：At this stage, [input] is divided into [number] streams. / [items] are either [treatment A] or [treatment B].
- **自然例句**：At this stage, the fish are either frozen or packed into cans.
- **例句依据**：教练自拟有明确分支的流程
- **可换内容**：分流→is split into two streams；汇合→the two streams are then combined；两种处理按图替换
- **用法要点**：分流两路的材料可分别作后续主语；替代处理用either...or连接平行的过去分词。图若显示汇合，接then combined交代重新合流。
- **短练习**：自拟流程：水分两路，各经过过滤器，随后合流入水箱。写2句。
- **教师参考**：The water is divided into two streams, each of which passes through a filter. The streams are then combined and directed into a tank.
- **评价点**：分流、各自过滤、合流三关系齐全；each of which配passes。
- **来源与归属**：M08:p15制糖替代收割；本轮扩展分流与合流。本轮教练补充；所列原材料提供教学场景或题图，卡片解释与练习为本轮新写；外部核验：[S26](#source-s26)、[S27](#source-s27)。

### T49 the cycle repeats / return to the beginning of the process（流程·核心）

- **精准含义**：处理结果回到先前阶段，开始下一轮。
- **适用条件**：流程有返回箭头，或生命周期各阶段形成闭环。
- **句架槽位**：The cycle repeats when [material/product] returns to [earlier stage].
- **自然例句**：The recycling cycle can begin again when the newly produced bottles are discarded and collected.
- **例句依据**：教练依据本批原图自写
- **可换内容**：cycle→production cycle / life cycle；returns to→is fed back into，按箭头选择
- **用法要点**：cycle作名词；repeat作动词。先指出回流的具体物料和返回节点，再描述下一轮；本批回收图可追踪新瓶进入回收端。
- **短练习**：塑料瓶回收图中，新瓶用完后再次收集。用cycle写一句。
- **教师参考**：The cycle can repeat when the new bottles are collected for recycling.
- **评价点**：回流对象为bottles；可用can呈现图示再次进入流程的可能。
- **来源与归属**：M08:p19返回箭头；本轮补循环语言。本轮教练补充；所列原材料提供教学场景或题图，卡片解释与练习为本轮新写；外部核验：[S14](#source-s14)、[S26](#source-s26)。

### T50 adjacent to / opposite（地图·核心）

- **精准含义**：紧邻某地标；位于某地标对面。
- **适用条件**：地图上有清楚的相邻或相对位置关系。
- **句架槽位**：A was built adjacent to B. / A is opposite B, across [road/space].
- **自然例句**：The café is opposite the library, across the main road.
- **例句依据**：教练自拟有位置关系的地图
- **可换内容**：adjacent to→next to；opposite后→library / entrance；across后写分隔区域
- **用法要点**：adjacent通常作形容词配to；opposite在此作介词直接接地标。把参照物与中间道路一起写，有助于定位。
- **短练习**：自拟图：停车场紧邻车站；咖啡馆位于图书馆隔街对面。各写一句。
- **教师参考**：The car park is adjacent to the station. The café is opposite the library, across the street.
- **评价点**：相邻与对面分别对应图中关系；adjacent to和opposite结构完整。
- **来源与归属**：M08:p20、p26方位；本轮补相邻关系。本轮教练补充；所列原材料提供教学场景或题图，卡片解释与练习为本轮新写；外部核验：[S28](#source-s28)、[S29](#source-s29)。

### T51 be extended to the ... / an extension was added（地图·核心）

- **精准含义**：建筑或道路向某方向延伸，或增加新部分。
- **适用条件**：地图画出新增的建筑轮廓、翼楼或道路延伸段。
- **句架槽位**：[building/road] was extended to the [direction]. / An extension was added to the [side] of [building].
- **自然例句**：The library was extended to the east, with a new reading room added.
- **例句依据**：教练自拟带指南针的改建图
- **可换内容**：extended→expanded，强调占地变大；direction→north / west；extension→new wing
- **用法要点**：extend为及物动词时可组成was extended；to the east说明延伸方向。面积倍数可由题图的尺寸或比例数据另行支持。
- **短练习**：自拟有指南针地图：学校北侧加一座翼楼。用extension写一句。
- **教师参考**：An extension was added to the northern side of the school.
- **评价点**：新增部分、北侧和学校对应；被动时态按图年份选择。
- **来源与归属**：M08:p26延伸和扩建；本轮补用途承接。本轮教练补充；所列原材料提供教学场景或题图，卡片解释与练习为本轮新写；外部核验：[S15](#source-s15)、[S26](#source-s26)。

### T52 be accessed via / be connected to ... by ...（地图·核心）

- **精准含义**：经某入口或道路到达；通过某路径与另一处连接。
- **适用条件**：地图清楚标出道路、入口和连接关系。
- **句架槽位**：A can be accessed via B. / A is connected to B by [route].
- **自然例句**：In 2010, the public car park could be accessed via Ring Road.
- **例句依据**：教练依据本批原图自写
- **可换内容**：via→from，按路线含义选择；route→a path / a bridge / a road
- **用法要点**：be accessed强调可到达的设施；via后接经过的路径；by后在连接句中写连接设施。过去图用could be accessed/was connected。
- **短练习**：用医院图写公共停车场的通达路线。
- **教师参考**：The public car park was accessed from Ring Road.
- **评价点**：公共停车场与Ring Road连接；参照2010图。
- **来源与归属**：M08:p21–22医院道路；p26连接表达。本轮教练补充；所列原材料提供教学场景或题图，卡片解释与练习为本轮新写；外部核验：[S26](#source-s26)。

## 研究来源与核验范围

核验日期：2026-10-16。正文读取与检索摘录读取分别标注。定义和规则采用中文概括；英语例句为教练自写。百分点及倍数算例按列出的算式独立计算。

<a id="source-s01"></a>

**S01 [IELTS：Preparing learners for Task 1](https://ielts.org/news-and-insights/preparing-learners-for-task-1-on-the-ielts-academic-writing-test)** — 页面正文已读，2026-10-16。正文Responding to the Task与Building lexical resource：概述主要特征、细节分组、动词副词/形容词名词搭配和流程顺序衔接。

<a id="source-s02"></a>

**S02 [Cambridge Learner’s Dictionary：stand](https://dictionary.cambridge.org/dictionary/learner-english/stand)** — 检索可见摘录核验，2026-10-16。检索可见stand at指处于某水平/数额；词形stood。直接打开返回403，核验依据为可见词条摘录。

<a id="source-s03"></a>

**S03 [Cambridge：record](https://dictionary.cambridge.org/dictionary/english/record)** — 检索可见摘录核验，2026-10-16。检索可见动词的测量并显示数值义，以及Business English呈现收益/变化的用法；图表recorded the highest figure为教练据义项组合。

<a id="source-s04"></a>

**S04 [Cambridge：initial](https://dictionary.cambridge.org/us/dictionary/english/initial)** — 检索可见摘录核验，2026-10-16。检索可见形容词before noun，表示开始时的；initial figure为教练组合。

<a id="source-s05"></a>

**S05 [Cambridge：final](https://dictionary.cambridge.org/dictionary/english/final)** — 检索可见摘录核验，2026-10-16。检索可见最后阶段/系列末尾的形容词义与final figures等搭配。

<a id="source-s06"></a>

**S06 [Cambridge：throughout](https://dictionary.cambridge.org/dictionary/english/throughout)** — 检索可见摘录核验，2026-10-16。检索可见介词/副词，时间义覆盖整个时期；直接打开返回403。

<a id="source-s07"></a>

**S07 [Cambridge Grammar：Following or the following?](https://dictionary.cambridge.org/us/grammar/british-grammar/following-or-the-following)** — 检索可见摘录核验，2026-10-16。检索可见the following + 名词表示接下来的；直接打开返回403。

<a id="source-s08"></a>

**S08 [Cambridge Essential：decade](https://dictionary.cambridge.org/dictionary/essential-british-english/decade)** — 检索可见摘录核验，2026-10-16。检索可见decade为十年期间；本轮据此核对1997后的十年为1997–2007。

<a id="source-s09"></a>

**S09 [Cambridge：level off](https://dictionary.cambridge.org/dictionary/english/level-off)** — 检索可见摘录核验，2026-10-16。检索可见数值升降后稳定、level off at搭配及英美拼写；直接打开返回403。

<a id="source-s10"></a>

**S10 [Cambridge：plateau](https://dictionary.cambridge.org/us/dictionary/english/plateau)** — 检索可见摘录核验，2026-10-16。检索可见水平稳定阶段的名词义、reach a plateau及动词达到某水平后稳定；对应英文基础页直接打开返回403。

<a id="source-s11"></a>

**S11 [Cambridge：fluctuate](https://dictionary.cambridge.org/dictionary/english/fluctuate)** — 检索可见摘录核验，2026-10-16。检索可见反复变化及fluctuate between A and B；直接打开返回403。

<a id="source-s12"></a>

**S12 [Cambridge：range（ranging词形页）](https://dictionary.cambridge.org/dictionary/english/ranging)** — 检索可见摘录核验，2026-10-16。检索可见上下限义、range from A to B与range between A and B。

<a id="source-s13"></a>

**S13 [Cambridge：rapid](https://dictionary.cambridge.org/dictionary/english/rapid)** — 检索可见摘录核验，2026-10-16。检索可见fast/sudden的形容词义和rapidly副词形式；本轮将其用于时间进程说明。

<a id="source-s14"></a>

**S14 [Cambridge：cycle](https://dictionary.cambridge.org/dictionary/english/cycle)** — 检索可见摘录核验，2026-10-16。检索可见按顺序发生并重复的系列；直接打开返回403。循环句架依据该义项与本批返回箭头自写。

<a id="source-s15"></a>

**S15 [Oxford：extend](https://www.oxfordlearnersdictionaries.com/definition/english/extend)** — 页面正文已读，2026-10-16。正文第1义为使物体更长/更大，包含道路、房屋及游乐区扩建；词形extended。

<a id="source-s20"></a>

**S20 [Cambridge：percentage point](https://dictionary.cambridge.org/dictionary/english/percentage-point)** — 检索可见摘录核验，2026-10-16。研究代理检索可见百分点定义及比例变化用法；直接打开返回Internal Error。相对增幅公式与算例为本轮独立推导。

<a id="source-s21"></a>

**S21 [Cambridge Grammar：Amount of, number of or quantity of?](https://dictionary.cambridge.org/us/grammar/british-grammar/amount-of-number-of-or-quantity-of)** — 检索可见摘录核验，2026-10-16。研究代理检索可见amount of配不可数、number of配可数；quantity of可配两类且语体较正式。直接打开返回Internal Error。

<a id="source-s22"></a>

**S22 [Oxford：twice](https://www.oxfordlearnersdictionaries.com/definition/english/twice)** — 页面正文已读，2026-10-16。正文第2义数量/比率两倍及twice the size、twice as much as等结构。

<a id="source-s23"></a>

**S23 [Oxford：double determiner](https://www.oxfordlearnersdictionaries.com/definition/english/double_2)** — 页面正文已读，2026-10-16。正文限定词义为两倍的量/数量，包含double the amount；用于静态倍数。

<a id="source-s24"></a>

**S24 [Oxford：halve](https://www.oxfordlearnersdictionaries.com/definition/english/halve)** — 页面正文已读，2026-10-16。正文第1义为减半，含及物/不及物用法、halved/halving、to等搭配。

<a id="source-s25"></a>

**S25 [British Council：Past perfect](https://learnenglish.britishcouncil.org/free-resources/grammar/b1-b2/past-perfect)** — 页面正文已读，2026-10-16。正文Time up to a point in the past说明had + past participle从过去参照点回看先前事件。

<a id="source-s26"></a>

**S26 [British Council：Passives](https://learnenglish.britishcouncil.org/free-resources/grammar/b1-b2/passives)** — 页面正文已读，2026-10-16。正文be + past participle以及be体现时态；受处理对象成为主语。

<a id="source-s27"></a>

**S27 [Cambridge Grammar：Either … or …](https://dictionary.cambridge.org/grammar/british-grammar/either-or)** — 检索可见摘录核验，2026-10-16。研究代理检索可见连接两项选择、两侧保持相同语法类型；直接打开返回Internal Error。

<a id="source-s28"></a>

**S28 [Oxford：adjacent](https://www.oxfordlearnersdictionaries.com/definition/english/adjacent)** — 页面正文已读，2026-10-16。正文位于旁边的义项及adjacent to搭配。

<a id="source-s29"></a>

**S29 [Oxford：opposite preposition](https://www.oxfordlearnersdictionaries.com/definition/english/opposite_3)** — 页面正文已读，2026-10-16。正文介词第1义为位于某区域另一侧相对位置，含隔路对面语境。

<a id="source-s30"></a>

**S30 [Oxford：convert](https://www.oxfordlearnersdictionaries.com/definition/english/convert_1)** — 页面正文已读，2026-10-16。正文第1义形式或用途改变；convert something into something及建筑改用途被动形式。

<a id="source-s31"></a>

**S31 [Oxford：place— in place](https://www.oxfordlearnersdictionaries.com/definition/english/place_1)** — 页面正文已读，2026-10-16。正文in place含处于适当位置义；remained in place由教练据位置义组合。

<a id="source-s32"></a>

**S32 [British Council：Modifying comparatives](https://learnenglish.britishcouncil.org/comment/212014)** — 页面正文已读，2026-10-16。正文slightly/much higher及roughly the same as；2025-05-01官方教师回复讲解twice/three times + as + adjective + as。

<a id="source-s33"></a>

**S33 [Oxford：double verb](https://www.oxfordlearnersdictionaries.com/us/definition/english/double_4)** — 页面正文已读，2026-10-16。正文动词第1义为变为两倍；及物/不及物、doubled/doubling及to/in搭配。

