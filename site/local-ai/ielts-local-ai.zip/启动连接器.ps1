﻿$ErrorActionPreference = 'Stop'
$taskNode = (Get-Command node -ErrorAction SilentlyContinue).Source
if (-not $taskNode) {
  $taskBundledNode = Join-Path $env:USERPROFILE '.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe'
  if (Test-Path -LiteralPath $taskBundledNode) { $taskNode = $taskBundledNode }
}
if (-not $taskNode) { throw '请先安装 Node.js 20 或更新版本，再启动连接器。' }
try { $connection = Invoke-RestMethod -Uri 'http://127.0.0.1:8831/api/connection' -Method Post -ContentType 'application/json' -Headers @{'X-IELTS-Coach'='1'} -Body '{}' -TimeoutSec 5 } catch { $connection = $null }
if (-not (Get-NetTCPConnection -LocalAddress 127.0.0.1 -LocalPort 8831 -State Listen -ErrorAction SilentlyContinue)) {
  Start-Process -FilePath $taskNode -ArgumentList @('server.cjs') -WorkingDirectory $PSScriptRoot -WindowStyle Hidden -RedirectStandardOutput (Join-Path $PSScriptRoot 'connector.log') -RedirectStandardError (Join-Path $PSScriptRoot 'connector-error.log') | Out-Null
}
Write-Output '本机连接地址：http://127.0.0.1:8831'
Write-Output '打开写作题的本地 AI 设置，选择服务并点击保存并连接。'
